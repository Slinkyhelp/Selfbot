const express = require("express");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const db = require("./database");
const authRoutes = require("./auth");

const app = express();
const PORT = 3000;

app.use(express.static("public"));
app.use(express.json());
app.use(authRoutes);

app.get("/generate-skin", async (req, res) => {
    if (!req.user) {
        return res.status(401).send("You must be logged in to generate a skin.");
    }

    try {
        const response = await axios.get("https://api.example.com/generate-skin", {
            responseType: "arraybuffer",
        });

        const skinPath = `skins/${req.user.id}_${Date.now()}.png`;
        fs.writeFileSync(skinPath, response.data);

        db.run("INSERT INTO skins (user_id, skin_path) VALUES (?, ?)", [req.user.id, skinPath]);

        res.sendFile(path.join(__dirname, skinPath));
    } catch (error) {
        console.error("Error generating AI skin:", error);
        res.status(500).send("AI skin generation failed");
    }
});

app.get("/user-skins", (req, res) => {
    if (!req.user) {
        return res.status(401).send("Not logged in");
    }

    db.all("SELECT skin_path FROM skins WHERE user_id = ?", [req.user.id], (err, rows) => {
        if (err) {
            res.status(500).send("Database error");
        } else {
            res.json(rows);
        }
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
