const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("./skincrafter.db");

db.run(`
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT,
        avatar TEXT
    )
`);

db.run(`
    CREATE TABLE IF NOT EXISTS skins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        skin_path TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
`);

module.exports = db;
