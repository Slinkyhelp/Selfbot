async function fetchUserSkins() {
    const response = await fetch("/user-skins");
    if (response.ok) {
        const skins = await response.json();
        const userSkins = document.getElementById("userSkins");
        userSkins.innerHTML = skins.map(skin => `<img src="${skin.skin_path}" width="100">`).join("");
    }
}

document.getElementById("generateBtn").addEventListener("click", async () => {
    const response = await fetch("/generate-skin");
    const data = await response.blob();

    const imgURL = URL.createObjectURL(data);
    const skinPreview = document.getElementById("skinPreview");
    skinPreview.innerHTML = `<img src="${imgURL}" alt="Generated Skin">`;

    const downloadLink = document.getElementById("downloadLink");
    downloadLink.href = imgURL;
    downloadLink.style.display = "block";

    fetchUserSkins();
});

fetchUserSkins();
